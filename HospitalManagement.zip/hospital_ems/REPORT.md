# Mini-Project Report
## Hospital Emergency Management System
*Data Structures Mini-Project - Python and Streamlit*

---

## 1. Introduction
Hospital emergency departments must decide quickly who is treated first. A patient with chest pain should not wait behind someone with a mild cold, yet patients of the same urgency should be served fairly in the order they arrived. This mini-project simulates that workflow with a web dashboard built in Python and Streamlit. Its purpose is to show how two core data structures - the **linked list** and the **priority queue** - solve a realistic problem. The system is an educational simulation and not a real clinical triage tool.

## 2. Problem Statement
Design and implement a hospital emergency management system that:
- registers patients with an ID, name, age, symptoms and emergency status;
- treats Emergency patients before Normal patients;
- treats patients of equal priority strictly in first-in-first-out (FIFO) order;
- stores patient records dynamically without relying on built-in lists or databases;
- keeps a treatment history, supports searching and provides dashboard statistics.

## 3. Objectives
1. Implement a singly linked list manually with nodes and references.
2. Implement a FIFO queue and a two-level priority queue manually.
3. Demonstrate enqueue, dequeue, priority handling, insertion, traversal, searching and record updates.
4. Provide a clear, responsive dashboard that a beginner can demonstrate in a few minutes.
5. Validate all user input and verify the logic with automated tests.

## 4. Methodology
1. **Analysis** - identified the operations needed: register, call next patient, complete treatment, search, update, report.
2. **Design** - selected data structures per operation (Section 5) and separated the project into layers: data structures (`linked_list.py`, `queues.py`), business logic (`system.py`, `validators.py`, `models.py`) and user interface (`app.py`).
3. **Implementation** - wrote the structures from scratch using `Node` objects and `next` references; Streamlit session state keeps one `HospitalSystem` per browser session.
4. **Validation** - checks on ID format and uniqueness, name characters, age range 0-120 and symptom length, with clear error messages.
5. **Testing** - unit tests for each structure and the full patient flow, plus scripted UI tests that click every page and button.

**Patient lifecycle:** `Register → Waiting (in queue) → In Treatment (dequeued) → Treated (added to history)`.

## 5. Data Structures Used

### 5.1 Singly Linked List (`LinkedList`, `Node`)
Each node holds a patient and a `next` reference. The list keeps `head`, `tail` and `size`.

| Use | Insertion | Why |
|---|---|---|
| All patient records | at tail, O(1) | keeps arrival order |
| Treatment history | at head, O(1) | newest treatment appears first |
| Activity log | at head, O(1) | newest operation appears first |

Operations: insert at head, insert at tail, traversal (generator), linear search with node-visit count, search-all, delete. Record updates first search for the node, then modify the stored patient object.

### 5.2 Queue (`Queue`)
A linked-node FIFO queue with `front` and `rear` references. `enqueue` adds at the rear and `dequeue` removes from the front, both O(1). `peek` shows the next item without removing it. A `remove` operation supports escalation.

### 5.3 Priority Queue (`PriorityQueue`)
Two FIFO queues - **Emergency** (high) and **Normal** (low). `enqueue(patient, priority)` places the patient in the matching queue. `dequeue()` returns from the Emergency queue while it is not empty, otherwise from the Normal queue.
Because each level is a FIFO queue, patients with the same priority are always treated in arrival order. This design is simple to explain and has O(1) enqueue and dequeue.

### 5.4 Complexity summary

| Operation | Structure | Time |
|---|---|---|
| Register | list tail insert + enqueue | O(1) |
| Treat next | dequeue | O(1) |
| Mark completed | list head insert | O(1) |
| Search / update | linear search | O(n) |
| View all records | traversal | O(n) |
| Escalate Normal → Emergency | queue remove + enqueue | O(n) |

## 6. Results
The application runs as a multi-page dashboard with a sidebar: Dashboard, Register Patient, Waiting Queue, Treatment Desk, All Records, Search Patients, Treatment History and Data Structure Lab. A blue and teal colour scheme with status badges (Emergency, Normal, Waiting, In Treatment, Treated) and boxed queue diagrams (FRONT → … → REAR) makes the state of the system easy to read.

**Sample data** (7 patients: 3 Emergency, 4 Normal) produces this treatment order:
`P001, P004, P006` (Emergency, FIFO) followed by `P002, P003, P005, P007` (Normal, FIFO).

Test results:
- Emergency patients were always dequeued before Normal patients.
- Equal-priority patients were served in arrival order.
- A newly registered Emergency patient joined the rear of the Emergency queue and was treated before all waiting Normal patients.
- Duplicate IDs, invalid names, out-of-range ages and empty symptoms were rejected with messages.
- Search reported the number of linked-list nodes visited; updates changed the shared record, visible in both the queue and the records table.
- All automated unit tests and scripted UI tests passed.

## 7. Conclusion
The project meets its objectives: patient records are held in a manually implemented linked list; an Emergency/Normal priority queue serves Emergency patients first and keeps FIFO order inside each priority; and a clear dashboard exposes every operation. It shows how choosing the right data structure for each task (tail insertion for arrival order, head insertion for newest-first history, queues for fair scheduling) gives simple and efficient code.

**Limitations and future work:** the system models one doctor and two priority levels, stores data only in memory, and does not assess medical severity. Possible extensions include several doctors, more priority levels with a heap, persistent storage, and time-based alerts for long waits.

*Disclaimer: this is an educational simulation and must not be used for real medical decisions.*
