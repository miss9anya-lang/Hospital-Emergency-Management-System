import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hems.linked_list import LinkedList
from hems.queues import Queue, PriorityQueue
from hems.system import HospitalSystem
from hems.samples import load_samples


def test_linked_list_insert_search_delete():
    ll = LinkedList()
    ll.insert_at_tail(2); ll.insert_at_tail(3); ll.insert_at_head(1)
    assert list(ll.traverse()) == [1, 2, 3]
    assert ll.search(lambda x: x == 3) == (3, 3)
    assert ll.search(lambda x: x == 9) == (None, 3)
    assert ll.delete(lambda x: x == 3) and ll.tail.data == 2
    assert ll.delete(lambda x: x == 1) and ll.head.data == 2
    assert len(ll) == 1


def test_queue_fifo():
    q = Queue()
    for i in (1, 2, 3):
        q.enqueue(i)
    assert [q.dequeue(), q.dequeue(), q.dequeue(), q.dequeue()] == [1, 2, 3, None]
    assert q.is_empty() and q.rear is None


def test_priority_order_and_fifo_within_priority():
    pq = PriorityQueue()
    pq.enqueue("n1", "Normal"); pq.enqueue("e1", "Emergency")
    pq.enqueue("n2", "Normal"); pq.enqueue("e2", "Emergency")
    assert [pq.dequeue() for _ in range(4)] == ["e1", "e2", "n1", "n2"]


def test_system_flow_and_validation():
    s = HospitalSystem(); load_samples(s)
    st = s.stats()
    assert (st["total"], st["emergency"], st["normal"], st["waiting"]) == (7, 3, 4, 7)
    order = [p.patient_id for p in s.waiting.traverse()]
    assert order == ["P001", "P004", "P006", "P002", "P003", "P005", "P007"]
    assert s.treat_next()[0] and s.current.patient_id == "P001"
    assert not s.treat_next()[0]                       # must finish first
    assert s.complete_treatment()[0] and s.stats()["treated"] == 1
    assert not s.register_patient("P001", "Dup", 20, "cough", "Normal")[0]
    assert not s.register_patient("", "", 200, "", "x")[0]
    assert s.escalate("P002")[0]
    assert [p.patient_id for p in s.waiting.traverse()][:3] == ["P004", "P006", "P002"]
    assert s.update_patient("P003", "Mohan P", 36, "Ankle swelling")[0]
    assert s.find_by_id("p003").age == 36
    matches, visited = s.search("fever", "Symptoms")
    assert len(matches) == 2 and visited == 7
