# 🏥 Hospital Emergency Management System

A Data Structures mini-project built with **Python + Streamlit**.
Emergency patients are treated first through a **priority queue**; Normal patients follow **FIFO**;
all records live in a **hand-written linked list**.

> ⚠️ Educational simulation only. This is **not** a real clinical triage system.

## Features
- Register patients (ID, name, age, symptoms, Emergency/Normal) with input validation
- Priority queue: Emergency first, FIFO inside each priority
- Buttons: Register, Treat Next, Mark Completed, view waiting queue, view all records
- Treatment history (linked list, newest first), record search (shows nodes visited), record update
- Escalate a waiting Normal patient to Emergency
- Dashboard: total / emergency / normal / waiting / in treatment / treated
- Queue visualisation (FRONT → … → REAR) and a **Data Structure Lab** page with the linked list, complexity table and activity log
- 7 sample patients preloaded

## Installation
Requires Python 3.9 or newer.

```bash
# 1. unzip and enter the folder
cd hospital_ems

# 2. (optional) create a virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # macOS / Linux

# 3. install dependencies
pip install -r requirements.txt
```

## Run
```bash
streamlit run app.py
```
Your browser opens at http://localhost:8501.

## Run the tests (optional)
```bash
pip install pytest
pytest tests
```

## Project structure
```
hospital_ems/
├── app.py                  Streamlit UI (sidebar, pages, styling)
├── requirements.txt
├── README.md
├── REPORT.md               Mini-project report
├── .streamlit/config.toml  Light blue/teal theme
├── hems/
│   ├── linked_list.py      Node + LinkedList (insert head/tail, traverse, search, delete)
│   ├── queues.py           Queue (FIFO) + PriorityQueue (Emergency / Normal)
│   ├── system.py           HospitalSystem: ties the structures together
│   ├── models.py           Patient dataclass, time formatting
│   ├── validators.py       Input validation
│   └── samples.py          Sample patients
└── tests/test_structures.py
```

## 5-minute demo script
1. **Dashboard** - 7 sample patients: 3 Emergency, 4 Normal, all waiting.
2. **Waiting Queue** - see the Emergency queue and Normal queue; the table shows the exact treatment order.
3. **Treatment Desk → Treat Next** - P001 (first Emergency) is dequeued. Press **Mark Completed**. Repeat: all Emergency patients go before P002.
4. **Register Patient** - add a new *Emergency* patient: they join the rear of the Emergency queue and jump ahead of every Normal patient. Try an invalid age or duplicate ID to show validation.
5. **Search Patients** - search `fever` by Symptoms; note "nodes visited".
6. **All Records** - update a patient's symptoms (record update in the linked list).
7. **Treatment History** - newest treatment first (head insertion).
8. **Data Structure Lab** - show HEAD → … → None and the activity log of enqueue/dequeue/insert operations.

## Notes
- Data is stored in memory per browser session; refreshing the page restarts with sample data.
- One doctor treats one patient at a time (finish the current patient before calling the next).
- Python lists appear only to hand results to the UI tables; all storage uses the custom linked structures.
