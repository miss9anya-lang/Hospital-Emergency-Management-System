"""
Hospital Emergency Management System  -  Data Structures mini-project
Educational simulation (NOT a real clinical triage system).

Run with:   streamlit run app.py
"""
import html

import pandas as pd
import streamlit as st

from hems.models import IN_TREATMENT, TREATED, WAITING, fmt_duration, fmt_time
from hems.samples import load_samples
from hems.system import HospitalSystem

st.set_page_config(page_title="Hospital Emergency Management System",
                   page_icon="🏥", layout="wide")

PAGES = ["🏠 Dashboard", "📝 Register Patient", "⏳ Waiting Queue",
         "🩺 Treatment Desk", "📋 All Records", "🔍 Search Patients",
         "🗂️ Treatment History", "🧪 Data Structure Lab"]

CSS = """
<style>
.stApp {background:#ffffff;}
section[data-testid="stSidebar"] {background:#F0F7FA; border-right:1px solid #D5E7EE;}
.brand {background:linear-gradient(135deg,#0B5FA5,#0E9AA7); color:#fff; padding:14px 16px;
        border-radius:14px; margin-bottom:12px;}
.brand h3 {margin:0; color:#fff; font-size:1.05rem;}
.brand p {margin:2px 0 0 0; font-size:.78rem; opacity:.9;}
.banner {background:linear-gradient(120deg,#0B5FA5 0%,#0E9AA7 100%); color:#fff;
         padding:20px 24px; border-radius:16px; margin-bottom:18px;}
.banner h1 {color:#fff; margin:0; font-size:1.7rem;}
.banner p {margin:4px 0 0 0; opacity:.92;}
.stat-grid {display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:14px; margin-bottom:18px;}
.stat-card {background:#fff; border:1px solid #D9E8EE; border-left:6px solid #0E9AA7;
            border-radius:14px; padding:14px 16px; box-shadow:0 2px 8px rgba(11,95,165,.07);}
.stat-card .num {font-size:2rem; font-weight:700; color:#0B5FA5; line-height:1.1;}
.stat-card .lbl {font-size:.82rem; color:#4A6072; text-transform:uppercase; letter-spacing:.04em;}
.stat-card.red {border-left-color:#E5484D;} .stat-card.red .num {color:#C62F34;}
.stat-card.blue {border-left-color:#2B7BE4;}
.stat-card.amber {border-left-color:#F5A524;} .stat-card.amber .num {color:#B97508;}
.stat-card.green {border-left-color:#2EA66A;} .stat-card.green .num {color:#1F7F4F;}
.panel {border:1px solid #D9E8EE; border-radius:14px; padding:14px 18px; background:#FAFDFE; margin-bottom:12px;}
.panel h4 {margin:0 0 6px 0; color:#0B5FA5;}
.badge {display:inline-block; padding:2px 10px; border-radius:999px; font-size:.78rem; font-weight:600;}
.badge.emergency {background:#FDECEC; color:#C62F34; border:1px solid #F3B7BA;}
.badge.normal {background:#E8F3FF; color:#1D63B8; border:1px solid #B5D5F5;}
.badge.waiting {background:#FFF4DC; color:#9A6200; border:1px solid #F5D690;}
.badge.treating {background:#DDF4F6; color:#0A7480; border:1px solid #9ADCE2;}
.badge.treated {background:#E1F6EA; color:#1F7F4F; border:1px solid #A5DEBF;}
.chain {display:flex; flex-wrap:wrap; align-items:center; gap:8px; margin:6px 0 4px 0;}
.chip {border-radius:12px; padding:8px 12px; min-width:130px; font-size:.85rem; line-height:1.3;}
.chip b {display:block; font-size:.95rem;} .chip small {color:#4A6072;}
.chip.emergency {background:#FDECEC; border:1.5px solid #E5484D;}
.chip.normal {background:#E8F3FF; border:1.5px solid #2B7BE4;}
.chip.plain {background:#F0F7FA; border:1.5px solid #0E9AA7;}
.chip.tag {background:#12263A; color:#fff; border:none; min-width:0; padding:4px 10px; font-weight:700;}
.arrow {font-size:1.3rem; color:#0E9AA7; font-weight:700;}
.empty {color:#7A8D9C; font-style:italic; padding:6px 0;}
.disclaimer {font-size:.75rem; color:#4A6072; background:#FFF8E6; border:1px solid #F5D690;
             padding:8px 10px; border-radius:10px;}
div.stButton > button {border-radius:10px; font-weight:600;}
</style>
"""


# ----------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------
def e(text):
    """HTML-escape any user-entered text before putting it in markup."""
    return html.escape(str(text))


def table(rows, **kw):
    """Show a table full-width (works across Streamlit versions)."""
    df = pd.DataFrame(rows)
    try:
        st.dataframe(df, hide_index=True, width="stretch", **kw)
    except TypeError:
        st.dataframe(df, hide_index=True, use_container_width=True, **kw)


def button(label, **kw):
    try:
        return st.button(label, width="stretch", **kw)
    except TypeError:
        return st.button(label, use_container_width=True, **kw)


def flash(kind, message):
    st.session_state.flash.append((kind, message))


def show_flash():
    for kind, message in st.session_state.flash:
        getattr(st, kind)(message)
    st.session_state.flash = []


def banner(title, subtitle):
    st.markdown(f'<div class="banner"><h1>{e(title)}</h1><p>{e(subtitle)}</p></div>',
                unsafe_allow_html=True)


def priority_badge(priority):
    return f'<span class="badge {priority.lower()}">{e(priority)}</span>'


def status_badge(status):
    css = {WAITING: "waiting", IN_TREATMENT: "treating", TREATED: "treated"}[status]
    return f'<span class="badge {css}">{e(status)}</span>'


PRIORITY_TXT = {"Emergency": "🔴 Emergency", "Normal": "🔵 Normal"}
STATUS_TXT = {WAITING: "⏳ Waiting", IN_TREATMENT: "🩺 In Treatment", TREATED: "✅ Treated"}


def patient_row(p):
    return {"ID": p.patient_id, "Name": p.name, "Age": p.age, "Symptoms": p.symptoms,
            "Priority": PRIORITY_TXT[p.priority], "Status": STATUS_TXT[p.status],
            "Arrived": fmt_time(p.arrival_time), "Arrival #": p.arrival_no}


def chain_html(patients, kind):
    """Draw a queue as boxes joined by arrows:  FRONT -> ... -> REAR."""
    items = list(patients)
    if not items:
        return '<div class="empty">Queue is empty</div>'
    parts = ['<div class="chip tag">FRONT</div>']
    for i, p in enumerate(items, start=1):
        parts.append('<div class="arrow">→</div>')
        parts.append(f'<div class="chip {kind}"><b>#{i} {e(p.name)}</b>'
                     f'<small>{e(p.patient_id)} · {p.age} yrs</small></div>')
    parts.append('<div class="arrow">→</div><div class="chip tag">REAR</div>')
    return f'<div class="chain">{"".join(parts)}</div>'


def current_card(p):
    return (f'<div class="panel"><h4>🩺 Now Treating</h4>'
            f'<b>{e(p.name)}</b> ({e(p.patient_id)}), {p.age} yrs {priority_badge(p.priority)} '
            f'{status_badge(p.status)}<br>Symptoms: {e(p.symptoms)}<br>'
            f'Started: {fmt_time(p.start_time)} · Waited: {fmt_duration(p.wait_seconds())}</div>')


# ----------------------------------------------------------------------
# Button callbacks (run BEFORE the page redraws)
# ----------------------------------------------------------------------
def do_treat_next():
    ok, msg = st.session_state.hms.treat_next()
    flash("success" if ok else "warning", msg)


def do_complete():
    ok, msg = st.session_state.hms.complete_treatment()
    flash("success" if ok else "warning", msg)


def do_load_samples():
    hms = st.session_state.hms
    if len(hms.records) > 0:
        flash("warning", "Sample data can only be loaded into an empty system. Reset first.")
        return
    load_samples(hms)
    flash("success", "Loaded 7 sample patients.")


def do_reset():
    if not st.session_state.get("confirm_reset"):
        flash("warning", "Tick the confirmation box first.")
        return
    st.session_state.hms.reset()
    st.session_state.confirm_reset = False
    st.session_state.form_ver += 1
    flash("info", "All data cleared.")


def do_escalate(patient_id):
    ok, msg = st.session_state.hms.escalate(patient_id)
    flash("success" if ok else "warning", msg)


# ----------------------------------------------------------------------
# Pages
# ----------------------------------------------------------------------
def page_dashboard(hms):
    banner("Hospital Emergency Management System",
           "Priority queue + linked list demonstration · educational simulation")
    s = hms.stats()
    cards = [("Total Patients", s["total"], ""), ("Emergency", s["emergency"], "red"),
             ("Normal", s["normal"], "blue"), ("Waiting", s["waiting"], "amber"),
             ("In Treatment", s["in_treatment"], ""), ("Treated", s["treated"], "green")]
    html_cards = "".join(f'<div class="stat-card {c}"><div class="num">{n}</div>'
                         f'<div class="lbl">{l}</div></div>' for l, n, c in cards)
    st.markdown(f'<div class="stat-grid">{html_cards}</div>', unsafe_allow_html=True)

    left, right = st.columns([3, 2])
    with left:
        if hms.current:
            st.markdown(current_card(hms.current), unsafe_allow_html=True)
        else:
            st.markdown('<div class="panel"><h4>🩺 Now Treating</h4>'
                        '<span class="empty">No patient in treatment</span></div>',
                        unsafe_allow_html=True)
        nxt = hms.waiting.peek()
        if nxt:
            st.markdown(f'<div class="panel"><h4>⏭️ Next Up (peek at front)</h4>'
                        f'<b>{e(nxt.name)}</b> ({e(nxt.patient_id)}) {priority_badge(nxt.priority)}'
                        f'<br>Symptoms: {e(nxt.symptoms)}</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="panel"><h4>⏭️ Next Up</h4>'
                        '<span class="empty">Nobody is waiting</span></div>',
                        unsafe_allow_html=True)
        c1, c2 = st.columns(2)
        with c1:
            button("▶️ Treat Next Patient", key="dash_treat", on_click=do_treat_next,
                   disabled=hms.current is not None or hms.waiting.is_empty())
        with c2:
            button("✅ Mark Completed", key="dash_done", on_click=do_complete,
                   disabled=hms.current is None)
    with right:
        st.markdown("**Patients by status**")
        chart = pd.DataFrame({"Patients": [s["waiting"], s["in_treatment"], s["treated"]]},
                             index=["Waiting", "In Treatment", "Treated"])
        st.bar_chart(chart, color="#0E9AA7")

    st.markdown("#### Treatment order (who is called next)")
    order = [{"Order": i, **{k: v for k, v in patient_row(p).items()
                              if k in ("ID", "Name", "Priority", "Symptoms")}}
             for i, p in enumerate(hms.waiting.traverse(), start=1)]
    if order:
        table(order)
    else:
        st.info("Nobody is waiting. Register a patient or load sample data from the sidebar.")


def page_register(hms):
    banner("Register Patient", "Adds a node to the linked list and enqueues the patient")
    ver = st.session_state.form_ver
    with st.form(f"register_form_{ver}"):
        c1, c2 = st.columns(2)
        pid = c1.text_input("Patient ID", value=hms.next_suggested_id(),
                            help="Unique. Letters, digits and '-' (2-12 chars).")
        name = c2.text_input("Full name", placeholder="e.g. Priya Menon")
        c3, c4 = st.columns(2)
        age = c3.number_input("Age", min_value=0, max_value=120, value=30, step=1)
        priority = c4.radio("Emergency status", ["Normal", "Emergency"], horizontal=True,
                            help="Emergency patients are always treated before Normal ones.")
        symptoms = st.text_area("Symptoms", placeholder="Describe the symptoms…", max_chars=200)
        submitted = st.form_submit_button("➕ Register Patient", type="primary")
    if submitted:
        ok, messages = hms.register_patient(pid, name, int(age), symptoms, priority)
        if ok:
            flash("success", messages[0])
            st.session_state.form_ver += 1
            st.rerun()
        for m in messages:
            st.error(m)
    st.caption("Tip: use the sidebar to load sample patients for a quick demo.")


def page_waiting(hms):
    banner("Waiting Queue", "Emergency queue is served first · each queue is FIFO")
    c1, c2, c3 = st.columns(3)
    c1.metric("🔴 Emergency waiting", len(hms.waiting.emergency))
    c2.metric("🔵 Normal waiting", len(hms.waiting.normal))
    c3.metric("Total waiting", len(hms.waiting))
    st.markdown("#### 🔴 Emergency queue (high priority)")
    st.markdown(chain_html(hms.waiting.emergency.traverse(), "emergency"), unsafe_allow_html=True)
    st.markdown("#### 🔵 Normal queue (FIFO)")
    st.markdown(chain_html(hms.waiting.normal.traverse(), "normal"), unsafe_allow_html=True)

    st.markdown("#### Waiting patients in treatment order")
    rows = []
    for i, p in enumerate(hms.waiting.traverse(), start=1):
        rows.append({"Order": i, "ID": p.patient_id, "Name": p.name, "Age": p.age,
                     "Priority": PRIORITY_TXT[p.priority], "Symptoms": p.symptoms,
                     "Arrived": fmt_time(p.arrival_time),
                     "Waiting for": fmt_duration(p.wait_seconds())})
    if rows:
        table(rows)
    else:
        st.info("The waiting queue is empty.")

    with st.expander("⬆️ Escalate a Normal patient to Emergency"):
        normals = list(hms.waiting.normal.traverse())
        if normals:
            labels = {f"{p.patient_id} - {p.name}": p.patient_id for p in normals}
            choice = st.selectbox("Waiting Normal patient", list(labels), key="esc_choice")
            button("Escalate to Emergency", key="esc_btn",
                   on_click=do_escalate, args=(labels[choice],))
            st.caption("The patient leaves the Normal queue and joins the REAR of the Emergency queue (FIFO).")
        else:
            st.write("No Normal patients are waiting.")


def page_treatment(hms):
    banner("Treatment Desk", "Dequeue the next patient, then mark treatment as completed")
    left, right = st.columns(2)
    with left:
        nxt = hms.waiting.peek()
        if nxt:
            st.markdown(f'<div class="panel"><h4>⏭️ Next in line</h4><b>{e(nxt.name)}</b> '
                        f'({e(nxt.patient_id)}) {priority_badge(nxt.priority)}<br>'
                        f'Symptoms: {e(nxt.symptoms)}</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="panel"><h4>⏭️ Next in line</h4>'
                        '<span class="empty">Nobody is waiting</span></div>', unsafe_allow_html=True)
        button("▶️ Treat Next Patient", key="desk_treat", type="primary", on_click=do_treat_next,
               disabled=hms.current is not None or hms.waiting.is_empty())
        if hms.current is not None:
            st.caption("Finish the current patient before calling the next one (single doctor).")
    with right:
        if hms.current:
            st.markdown(current_card(hms.current), unsafe_allow_html=True)
        else:
            st.markdown('<div class="panel"><h4>🩺 Now Treating</h4>'
                        '<span class="empty">No patient in treatment</span></div>', unsafe_allow_html=True)
        button("✅ Mark Treatment Completed", key="desk_done", on_click=do_complete,
               disabled=hms.current is None)
    st.markdown("#### Remaining queue")
    st.markdown("**Emergency**")
    st.markdown(chain_html(hms.waiting.emergency.traverse(), "emergency"), unsafe_allow_html=True)
    st.markdown("**Normal**")
    st.markdown(chain_html(hms.waiting.normal.traverse(), "normal"), unsafe_allow_html=True)


def page_records(hms):
    banner("All Patient Records", "Traversal of the linked list from HEAD to TAIL")
    c1, c2 = st.columns(2)
    status_f = c1.multiselect("Filter by status", [WAITING, IN_TREATMENT, TREATED],
                              default=[WAITING, IN_TREATMENT, TREATED])
    prio_f = c2.multiselect("Filter by priority", ["Emergency", "Normal"],
                            default=["Emergency", "Normal"])
    rows = [patient_row(p) for p in hms.records.traverse()
            if p.status in status_f and p.priority in prio_f]
    st.write(f"Showing **{len(rows)}** of **{len(hms.records)}** records")
    if rows:
        table(rows)
    else:
        st.info("No records to show.")

    st.markdown("#### ✏️ Update a record")
    if hms.records.is_empty():
        st.caption("Register a patient first.")
        return
    ids = [p.patient_id for p in hms.records.traverse()]
    pid = st.selectbox("Select patient ID", ids, key="edit_pid")
    patient = hms.find_by_id(pid)
    ver = st.session_state.form_ver
    with st.form(f"edit_form_{pid}_{ver}"):
        c1, c2 = st.columns(2)
        name = c1.text_input("Name", value=patient.name)
        age = c2.number_input("Age", min_value=0, max_value=120, value=int(patient.age), step=1)
        symptoms = st.text_area("Symptoms", value=patient.symptoms, max_chars=200)
        saved = st.form_submit_button("💾 Save changes", type="primary")
    if saved:
        ok, messages = hms.update_patient(pid, name, int(age), symptoms)
        if ok:
            flash("success", messages[0])
            st.rerun()
        for m in messages:
            st.error(m)


def page_search(hms):
    banner("Search Patients", "Linear search through the linked list")
    c1, c2 = st.columns([3, 1])
    text = c1.text_input("Search text", placeholder="e.g. P004, Sara, fever, waiting…")
    field = c2.selectbox("Search by", ["Patient ID", "Name", "Symptoms", "Status", "Priority"])
    if not text.strip():
        st.info("Type something to search.")
        return
    matches, visited = hms.search(text, field)
    st.write(f"Found **{len(matches)}** match(es) · linked-list nodes visited: **{visited}**")
    if matches:
        table([patient_row(p) for p in matches])
        if len(matches) == 1:
            p = matches[0]
            pos = hms.waiting.position_of(lambda x: x.patient_id == p.patient_id)
            if pos:
                st.success(f"{p.name} is #{pos} in the treatment order.")
    else:
        st.warning("No matching records.")


def page_history(hms):
    banner("Treatment History", "Newest treatments are inserted at the HEAD of a linked list")
    rows = []
    for i, p in enumerate(hms.history.traverse(), start=1):
        rows.append({"#": i, "ID": p.patient_id, "Name": p.name,
                     "Priority": PRIORITY_TXT[p.priority], "Symptoms": p.symptoms,
                     "Arrived": fmt_time(p.arrival_time), "Started": fmt_time(p.start_time),
                     "Completed": fmt_time(p.end_time),
                     "Waited": fmt_duration(p.wait_seconds()),
                     "Treatment time": fmt_duration(p.treatment_seconds())})
    st.write(f"Patients treated: **{len(rows)}**")
    if rows:
        table(rows)
    else:
        st.info("No completed treatments yet. Use the Treatment Desk.")


def page_lab(hms):
    banner("Data Structure Lab", "See the nodes and pointers behind the screens")
    st.markdown("#### Linked list of all records (HEAD → … → TAIL → None)")
    parts = ['<div class="chip tag">HEAD</div>']
    for p in hms.records.traverse():
        parts.append('<div class="arrow">→</div>')
        parts.append(f'<div class="chip plain"><b>{e(p.patient_id)}</b><small>{e(p.name)}<br>'
                     f'{STATUS_TXT[p.status]}</small></div>')
    parts.append('<div class="arrow">→</div><div class="chip tag">None</div>')
    st.markdown(f'<div class="chain">{"".join(parts)}</div>', unsafe_allow_html=True)
    st.caption("New patients are inserted at the TAIL in O(1) using the tail pointer.")

    st.markdown("#### Dequeue order preview")
    st.markdown(chain_html(hms.waiting.traverse(), "plain"), unsafe_allow_html=True)

    st.markdown("#### Operation complexity")
    table([
        {"Operation": "Register (insert at tail + enqueue)", "Structure": "Linked list + Queue", "Time": "O(1)"},
        {"Operation": "Treat next (dequeue)", "Structure": "Priority queue", "Time": "O(1)"},
        {"Operation": "Mark completed (insert at head)", "Structure": "Linked list", "Time": "O(1)"},
        {"Operation": "Search / update record", "Structure": "Linked list", "Time": "O(n)"},
        {"Operation": "View all / traverse", "Structure": "Linked list", "Time": "O(n)"},
        {"Operation": "Escalate (remove + enqueue)", "Structure": "Queue", "Time": "O(n)"},
    ])
    st.markdown("#### Activity log (newest first)")
    rows = [{"Time": fmt_time(t), "Data-structure operation": text}
            for i, (t, text) in enumerate(hms.activity_log.traverse()) if i < 25]
    if rows:
        table(rows)
    else:
        st.info("No operations yet.")


PAGE_FUNCS = {PAGES[0]: page_dashboard, PAGES[1]: page_register, PAGES[2]: page_waiting,
              PAGES[3]: page_treatment, PAGES[4]: page_records, PAGES[5]: page_search,
              PAGES[6]: page_history, PAGES[7]: page_lab}


# ----------------------------------------------------------------------
# App entry
# ----------------------------------------------------------------------
def main():
    st.markdown(CSS, unsafe_allow_html=True)
    if "hms" not in st.session_state:
        st.session_state.hms = HospitalSystem()
        load_samples(st.session_state.hms)       # start with sample data
        st.session_state.flash = []
        st.session_state.form_ver = 0
    hms = st.session_state.hms

    with st.sidebar:
        st.markdown('<div class="brand"><h3>🏥 Hospital Emergency<br>Management System</h3>'
                    '<p>Data Structures mini-project</p></div>', unsafe_allow_html=True)
        page = st.radio("Navigation", PAGES, key="page", label_visibility="collapsed")
        s = hms.stats()
        st.markdown(f"**Live:** 🔴 {len(hms.waiting.emergency)} emergency · "
                    f"🔵 {len(hms.waiting.normal)} normal waiting")
        st.divider()
        button("📥 Load sample patients", key="load_samples", on_click=do_load_samples)
        st.checkbox("Confirm reset", key="confirm_reset")
        button("🗑️ Reset all data", key="reset_all", on_click=do_reset)
        st.markdown('<div class="disclaimer">⚠️ Educational simulation only. '
                    'Not a real clinical triage system.</div>', unsafe_allow_html=True)

    show_flash()
    PAGE_FUNCS[page](hms)


main()
