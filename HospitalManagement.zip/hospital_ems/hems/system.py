"""
HospitalSystem - ties the data structures together.

  records      LinkedList     every patient ever registered (tail insertion)
  waiting      PriorityQueue  patients waiting for treatment
  history      LinkedList     treated patients (head insertion = newest first)
  activity_log LinkedList     what the data structures did (newest first)
  current      Patient/None   the patient being treated right now (one doctor)
"""
from datetime import datetime

from . import validators as v
from .linked_list import LinkedList
from .models import IN_TREATMENT, TREATED, WAITING, Patient
from .queues import PriorityQueue


class HospitalSystem:
    def __init__(self):
        self.reset()

    # ------------------------------------------------------------------
    def reset(self):
        self.records = LinkedList()
        self.waiting = PriorityQueue()
        self.history = LinkedList()
        self.activity_log = LinkedList()
        self.current = None
        self._arrival_counter = 0

    def _log(self, text):
        self.activity_log.insert_at_head((datetime.now(), text))

    # ------------------------------------------------------------------
    # Registration:  linked-list insertion + enqueue
    # ------------------------------------------------------------------
    def find_by_id(self, patient_id):
        patient, _ = self.records.search(
            lambda p: p.patient_id == patient_id.strip().upper())
        return patient

    def next_suggested_id(self):
        number = len(self.records) + 1
        while self.find_by_id(f"P{number:03d}") is not None:
            number += 1
        return f"P{number:03d}"

    def register_patient(self, patient_id, name, age, symptoms, priority):
        """Returns (ok, [messages])."""
        patient_id = (patient_id or "").strip().upper()
        name = " ".join((name or "").split())
        symptoms = " ".join((symptoms or "").split())

        errors = [e for e in (
            v.check_id(patient_id), v.check_name(name), v.check_age(age),
            v.check_symptoms(symptoms), v.check_priority(priority)) if e]
        if v.check_id(patient_id) is None and self.find_by_id(patient_id):
            errors.append(f"Patient ID {patient_id} already exists.")
        if errors:
            return False, errors

        self._arrival_counter += 1
        patient = Patient(patient_id, name.title(), age, symptoms, priority,
                          self._arrival_counter, datetime.now())
        self.records.insert_at_tail(patient)           # linked-list insertion
        self.waiting.enqueue(patient, priority)         # enqueue
        self._log(f"INSERT node for {patient_id} at TAIL of records list; "
                  f"ENQUEUE into {priority} queue")
        return True, [f"{patient.name} ({patient_id}) registered as {priority}."]

    # ------------------------------------------------------------------
    # Treatment:  dequeue -> in treatment -> completed -> history
    # ------------------------------------------------------------------
    def treat_next(self):
        if self.current is not None:
            return False, (f"Finish treating {self.current.name} "
                           f"({self.current.patient_id}) first.")
        patient = self.waiting.dequeue()
        if patient is None:
            return False, "No patients are waiting."
        patient.status = IN_TREATMENT
        patient.start_time = datetime.now()
        self.current = patient
        self._log(f"DEQUEUE {patient.patient_id} ({patient.priority}) "
                  f"-> treatment started")
        return True, f"Now treating {patient.name} ({patient.patient_id})."

    def complete_treatment(self):
        patient = self.current
        if patient is None:
            return False, "No patient is currently in treatment."
        patient.status = TREATED
        patient.end_time = datetime.now()
        self.current = None
        self.history.insert_at_head(patient)            # newest first
        self._log(f"INSERT {patient.patient_id} at HEAD of history list "
                  f"-> treatment completed")
        return True, f"Treatment completed for {patient.name} ({patient.patient_id})."

    # ------------------------------------------------------------------
    # Searching / updating / escalation
    # ------------------------------------------------------------------
    def search(self, text, field):
        """Linear search through the linked list. Returns (matches, visited)."""
        text = (text or "").strip().lower()
        getters = {
            "Patient ID": lambda p: p.patient_id.lower(),
            "Name": lambda p: p.name.lower(),
            "Symptoms": lambda p: p.symptoms.lower(),
            "Status": lambda p: p.status.lower(),
            "Priority": lambda p: p.priority.lower(),
        }
        getter = getters[field]
        return self.records.search_all(lambda p: text in getter(p))

    def update_patient(self, patient_id, name, age, symptoms):
        patient = self.find_by_id(patient_id)
        if patient is None:
            return False, ["Patient not found."]
        name = " ".join((name or "").split())
        symptoms = " ".join((symptoms or "").split())
        errors = [e for e in (v.check_name(name), v.check_age(age),
                              v.check_symptoms(symptoms)) if e]
        if errors:
            return False, errors
        patient.name, patient.age, patient.symptoms = name.title(), age, symptoms
        self._log(f"UPDATE record node of {patient.patient_id} (found by search)")
        return True, [f"Record of {patient.patient_id} updated."]

    def escalate(self, patient_id):
        """Move a WAITING Normal patient into the Emergency queue."""
        patient = self.find_by_id(patient_id)
        if patient is None:
            return False, "Patient not found."
        if patient.status != WAITING or patient.priority != "Normal":
            return False, "Only waiting Normal patients can be escalated."
        self.waiting.remove(lambda p: p.patient_id == patient.patient_id, "Normal")
        patient.priority = "Emergency"
        self.waiting.enqueue(patient, "Emergency")      # joins REAR of emergency
        self._log(f"ESCALATE {patient.patient_id}: removed from Normal queue, "
                  f"ENQUEUE at rear of Emergency queue")
        return True, f"{patient.name} escalated to Emergency (placed at the rear of that queue)."

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------
    def stats(self):
        emergency = normal = 0
        for patient in self.records.traverse():
            if patient.priority == "Emergency":
                emergency += 1
            else:
                normal += 1
        return {
            "total": len(self.records),
            "emergency": emergency,
            "normal": normal,
            "waiting": len(self.waiting),
            "in_treatment": 0 if self.current is None else 1,
            "treated": len(self.history),
        }
