"""Sample patients for testing / demonstration (educational data only)."""

SAMPLE_PATIENTS = [
    ("P001", "Ravi Kumar", 52, "Chest pain and shortness of breath", "Emergency"),
    ("P002", "Anita Sharma", 28, "Mild fever and sore throat", "Normal"),
    ("P003", "Mohan Patil", 35, "Sprained ankle after a fall", "Normal"),
    ("P004", "Sara Khan", 8, "High fever and difficulty breathing", "Emergency"),
    ("P005", "Vikram Joshi", 61, "Routine blood pressure check", "Normal"),
    ("P006", "Neha Desai", 24, "Heavy bleeding from a deep cut", "Emergency"),
    ("P007", "Arjun Rao", 19, "Seasonal allergy and sneezing", "Normal"),
]


def load_samples(system):
    """Register every sample patient through the normal registration path."""
    for row in SAMPLE_PATIENTS:
        system.register_patient(*row)
