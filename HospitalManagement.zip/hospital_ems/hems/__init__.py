"""Hospital Emergency Management System - core package (pure Python, no Streamlit)."""
