"""
Queue and Priority Queue written from scratch using linked nodes.

Queue           : FIFO  (enqueue at REAR, dequeue from FRONT)
PriorityQueue   : two FIFO queues - one per priority level.
                  dequeue() always serves ALL Emergency patients before ANY
                  Normal patient, and inside each level the order is FIFO.
"""
from .linked_list import Node


class Queue:
    """FIFO queue built on linked nodes (front/rear references)."""

    def __init__(self):
        self.front = None
        self.rear = None
        self.size = 0

    def enqueue(self, item):
        """Add to the rear.  O(1)"""
        node = Node(item)
        if self.rear is None:
            self.front = self.rear = node
        else:
            self.rear.next = node
            self.rear = node
        self.size += 1

    def dequeue(self):
        """Remove and return the front item (None if empty).  O(1)"""
        if self.front is None:
            return None
        node = self.front
        self.front = node.next
        if self.front is None:     # queue became empty
            self.rear = None
        self.size -= 1
        return node.data

    def peek(self):
        """Look at the front item without removing it."""
        return None if self.front is None else self.front.data

    def traverse(self):
        """Yield items from front to rear."""
        current = self.front
        while current is not None:
            yield current.data
            current = current.next

    def remove(self, predicate):
        """Remove the first item matching predicate (used for escalation)."""
        previous, current = None, self.front
        while current is not None:
            if predicate(current.data):
                if previous is None:
                    self.front = current.next
                else:
                    previous.next = current.next
                if current is self.rear:
                    self.rear = previous
                self.size -= 1
                return current.data
            previous, current = current, current.next
        return None

    def is_empty(self):
        return self.front is None

    def __len__(self):
        return self.size


class PriorityQueue:
    """Emergency (high) and Normal (low) queues behind one interface."""

    EMERGENCY = "Emergency"
    NORMAL = "Normal"

    def __init__(self):
        self.emergency = Queue()
        self.normal = Queue()

    def _queue_for(self, priority):
        if priority == self.EMERGENCY:
            return self.emergency
        if priority == self.NORMAL:
            return self.normal
        raise ValueError(f"Unknown priority: {priority}")

    def enqueue(self, item, priority):
        """Place the item at the rear of its own priority queue."""
        self._queue_for(priority).enqueue(item)

    def dequeue(self):
        """Highest priority first; FIFO inside the same priority."""
        if not self.emergency.is_empty():
            return self.emergency.dequeue()
        return self.normal.dequeue()

    def peek(self):
        if not self.emergency.is_empty():
            return self.emergency.peek()
        return self.normal.peek()

    def traverse(self):
        """Yield patients in the exact order they WILL be treated."""
        yield from self.emergency.traverse()
        yield from self.normal.traverse()

    def remove(self, predicate, priority):
        return self._queue_for(priority).remove(predicate)

    def position_of(self, predicate):
        """1-based position in treatment order (None if not waiting)."""
        for index, item in enumerate(self.traverse(), start=1):
            if predicate(item):
                return index
        return None

    def is_empty(self):
        return self.emergency.is_empty() and self.normal.is_empty()

    def __len__(self):
        return len(self.emergency) + len(self.normal)
