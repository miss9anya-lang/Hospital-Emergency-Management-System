"""Input validation helpers. Each returns an error message or None."""
import re

ID_PATTERN = re.compile(r"^[A-Za-z0-9\-]{2,12}$")
NAME_PATTERN = re.compile(r"^[A-Za-z][A-Za-z .'\-]{1,59}$")


def check_id(patient_id):
    if not patient_id:
        return "Patient ID is required."
    if not ID_PATTERN.match(patient_id):
        return "Patient ID must be 2-12 characters: letters, digits or '-' only."
    return None


def check_name(name):
    if not name:
        return "Name is required."
    if not NAME_PATTERN.match(name):
        return "Name must be 2-60 characters (letters, spaces, . ' - only)."
    return None


def check_age(age):
    if isinstance(age, bool) or not isinstance(age, int):
        return "Age must be a whole number."
    if age < 0 or age > 120:
        return "Age must be between 0 and 120."
    return None


def check_symptoms(symptoms):
    if not symptoms:
        return "Symptoms are required."
    if len(symptoms) < 3:
        return "Please describe the symptoms (at least 3 characters)."
    if len(symptoms) > 200:
        return "Symptoms must be 200 characters or fewer."
    return None


def check_priority(priority):
    if priority not in ("Emergency", "Normal"):
        return "Emergency status must be Emergency or Normal."
    return None
