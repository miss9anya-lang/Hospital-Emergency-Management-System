"""Patient data model."""
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

WAITING = "Waiting"
IN_TREATMENT = "In Treatment"
TREATED = "Treated"


@dataclass
class Patient:
    patient_id: str
    name: str
    age: int
    symptoms: str
    priority: str            # "Emergency" or "Normal"
    arrival_no: int          # global arrival sequence (1, 2, 3 ...)
    arrival_time: datetime
    status: str = WAITING
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    def wait_seconds(self):
        """Time spent waiting (still counting while the patient waits)."""
        end = self.start_time or datetime.now()
        return max(0, int((end - self.arrival_time).total_seconds()))

    def treatment_seconds(self):
        if self.start_time is None:
            return 0
        end = self.end_time or datetime.now()
        return max(0, int((end - self.start_time).total_seconds()))


def fmt_duration(seconds):
    seconds = int(seconds)
    minutes, secs = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}h {minutes}m {secs}s"
    if minutes:
        return f"{minutes}m {secs}s"
    return f"{secs}s"


def fmt_time(moment):
    return "-" if moment is None else moment.strftime("%H:%M:%S")
