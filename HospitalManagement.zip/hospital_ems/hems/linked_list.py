"""
Singly linked list written from scratch (nodes + references).

Used in the project for:
  * the master list of ALL patient records   (insert at tail  -> arrival order)
  * the treatment history                    (insert at head  -> newest first)
  * the activity log                         (insert at head  -> newest first)

No Python list / dict / database is used for STORAGE. (Python lists are only
used to hand results to the UI for display.)
"""


class Node:
    """One box in the chain: holds data and a reference to the next node."""

    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None   # first node
        self.tail = None   # last node (makes tail insertion O(1))
        self.size = 0

    # ---------- insertion ----------
    def insert_at_head(self, data):
        """Add a node at the front.  O(1)"""
        node = Node(data)
        node.next = self.head
        self.head = node
        if self.tail is None:      # list was empty
            self.tail = node
        self.size += 1

    def insert_at_tail(self, data):
        """Add a node at the end.  O(1) because we keep a tail pointer."""
        node = Node(data)
        if self.tail is None:      # list was empty
            self.head = self.tail = node
        else:
            self.tail.next = node
            self.tail = node
        self.size += 1

    # ---------- traversal ----------
    def traverse(self):
        """Walk from head to the end, yielding each node's data.  O(n)"""
        current = self.head
        while current is not None:
            yield current.data
            current = current.next

    # ---------- searching ----------
    def search(self, predicate):
        """
        Linear search for the FIRST item where predicate(item) is True.
        Returns (item_or_None, nodes_visited).  O(n)
        """
        visited = 0
        current = self.head
        while current is not None:
            visited += 1
            if predicate(current.data):
                return current.data, visited
            current = current.next
        return None, visited

    def search_all(self, predicate):
        """Return (list_of_matches, nodes_visited).  O(n)"""
        matches = []
        visited = 0
        current = self.head
        while current is not None:
            visited += 1
            if predicate(current.data):
                matches.append(current.data)
            current = current.next
        return matches, visited

    # ---------- deletion ----------
    def delete(self, predicate):
        """Remove the first node whose data matches.  Returns True if removed."""
        previous = None
        current = self.head
        while current is not None:
            if predicate(current.data):
                if previous is None:           # deleting the head
                    self.head = current.next
                else:
                    previous.next = current.next
                if current is self.tail:       # deleting the tail
                    self.tail = previous
                self.size -= 1
                return True
            previous = current
            current = current.next
        return False

    # ---------- helpers ----------
    def is_empty(self):
        return self.head is None

    def __len__(self):
        return self.size
